# @hashpaylink/sdk

React button and URL helpers for Hash PayLink hosted checkout.

Hash PayLink is stateless and non-custodial. The SDK does not hold funds, run wallet logic, or duplicate the production relayer path. It builds clean checkout URLs for the current Hash PayLink app.

```bash
npm install @hashpaylink/sdk
```

```tsx
import { PayLinkButton, buildPayLinkUrl } from '@hashpaylink/sdk'

export function InvoiceButton() {
  return (
    <PayLinkButton
      recipientEVM="0xYourMerchantAddress"
      network="base"
      amount="25"
      memo="Invoice #042"
    />
  )
}

const url = buildPayLinkUrl({
  recipientEVM: '0xYourMerchantAddress',
  recipientSolana: 'YourSolanaAddress',
  amount: '10',
  multiChain: true,
  memo: 'Order #1001',
})
```

Current public networks: `base`, `arbitrum`, `solana`, and `arc`.

Useful exports:

- `PayLinkButton`
- `buildPayLinkUrl`
- `SUPPORTED_NETWORKS`
- `CHAIN_META`
- `isValidEvmAddress`
- `isLikelySolanaAddress`
- `isValidUsdcAmount`


## Shared Circle wallet UI (candidate 1.1)

Import CircleWalletAccessScreen and circleOtpLogin from @hashpaylink/sdk/wallet;
import @hashpaylink/sdk/wallet.css once. The stylesheet includes Pocket's Plus
Jakarta Sans fonts and the existing Pocket access-screen styles.

Pass project={{ projectName: connection.projectName }} from your authenticated
server's wallet-connection response. Create, participant read, and redeem expose
the registered developer project name; request-body names are ignored. A local
productName is an explicit fallback for first-party apps without a connection.
The SDK does not discover an arbitrary app's API key or authenticate a project
from a display name. Keep developer keys and connection verifiers server-side.

Provide Circle-issued OTP credentials and a resend callback to circleOtpLogin.
Both Pocket's hosted flow and Hash PayStream use this same implementation.
The API adapter owns authentication, environment and wallet authorization;
the SDK owns code-entry presentation, close, resend, timeout and cleanup.
Pass an AbortSignal when accounts change. Native hosts provide
--hashpaylink-safe-top and --hashpaylink-safe-bottom on the document root.

This extraction does not transfer existing wallets or sessions between Circle
projects, enable a disabled hosted-account connection, or migrate testnet funds.
